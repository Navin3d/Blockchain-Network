package gmc.project.blockchain.miner.discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinerDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
