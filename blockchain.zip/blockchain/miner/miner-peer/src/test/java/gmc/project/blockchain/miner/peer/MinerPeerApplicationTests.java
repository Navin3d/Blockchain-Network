package gmc.project.blockchain.miner.peer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinerPeerApplicationTests {

	@Test
	void contextLoads() {
	}

}
