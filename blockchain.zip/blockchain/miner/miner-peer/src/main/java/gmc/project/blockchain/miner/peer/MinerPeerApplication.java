package gmc.project.blockchain.miner.peer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinerPeerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinerPeerApplication.class, args);
	}

}
