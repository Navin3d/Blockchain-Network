package gmc.project.blockchain.miner.hashchecker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinerHashCheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinerHashCheckerApplication.class, args);
	}

}
