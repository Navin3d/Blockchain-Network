package gmc.project.blockchain.minerprophet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinerProphetApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinerProphetApplication.class, args);
	}

}
