package gmc.project.blockchain.miner.hashgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinerHashGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
