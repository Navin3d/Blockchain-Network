package gmc.project.blockchain.miner.hashgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinerHashGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinerHashGeneratorApplication.class, args);
	}

}
