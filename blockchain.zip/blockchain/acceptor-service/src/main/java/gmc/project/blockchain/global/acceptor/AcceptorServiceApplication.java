package gmc.project.blockchain.global.acceptor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcceptorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcceptorServiceApplication.class, args);
	}

}
