package gmc.project.blockchain.global.acceptor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcceptorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
