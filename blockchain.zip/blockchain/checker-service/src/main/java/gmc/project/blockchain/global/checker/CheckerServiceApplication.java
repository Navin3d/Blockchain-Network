package gmc.project.blockchain.global.checker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheckerServiceApplication.class, args);
	}

}
